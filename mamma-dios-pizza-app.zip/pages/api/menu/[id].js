import { createServerSupabase } from '../../../lib/supabase'

export default async function handler(req, res) {
  const supabase = createServerSupabase()
  const { id } = req.query

  if (req.method === 'PATCH') {
    const { data, error } = await supabase
      .from('menu_items')
      .update(req.body)
      .eq('id', id)
      .select()
      .single()
    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json(data)
  }

  if (req.method === 'DELETE') {
    const { error } = await supabase.from('menu_items').delete().eq('id', id)
    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json({ deleted: true })
  }

  res.setHeader('Allow', ['PATCH', 'DELETE'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}
